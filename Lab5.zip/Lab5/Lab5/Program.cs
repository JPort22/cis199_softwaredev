﻿//Grading ID: M4318
//Lab 5
//03/03/2019
//CIS 199-01
//The purpose of this program is to gather data inputted by the user about temperatures
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables Declared
            int temp;//temperature entered by user
            int tempCount = 0;//counts of temperature for calculation
            int totalTemp = 0;//variable used to calculate temp
            double mean;//variable mean to calculate average
            const int minTemp = -20;//variable to hold constant of lowest temperature
            const int maxTemp = 130;//variable to hold constant of highest temperature
            const int STOP = 999;//variable to stop program
            bool valid;//variable to validate input
            
            //Code in the Beginning
            WriteLine("Enter temperatures from -20 to 130 (999 to stop)");

            Write("Enter temperature:");
            //Input from user
            valid = int.TryParse(ReadLine(), out temp);

            while (temp != STOP)
            {
                //error shows
                if (!valid || temp < minTemp || temp > maxTemp)
                {
                    WriteLine("Valid temperatures range from -20 to 130. Please reenter temperature.");
                }


                //temp calculations
                else
                {
                    totalTemp += temp;
                    tempCount++;
                }
                //end of loop input
                Write("Enter temperature: ");
                valid = int.TryParse(ReadLine(), out temp);
            }
            //Output
            WriteLine($"You entered {tempCount} valid temperatures.");
            mean = (double)totalTemp / tempCount;
            WriteLine($"The mean temperature is {mean:F1} degrees.");

        }
    }
}
