﻿/*Grading ID: 4318
Date: 01/28/2019
Lab 2
CIS 199-01
Purpose: This program calculates a tip when given the price of a meal.*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //The purpose of the button is to calculate the tip for the customer./
        private void calcTip_Click(object sender, EventArgs e)
        {
            double userMeal;//This is the entered price of meal./
            double lowTip;//This is the lowest tip percentage at 15 percent./
            double medTip;//This the most medium tip percentage at 18 percent./
            double hiTip;//This is the highest tip percentage at 20 percent./
            const double LOW_TIP_RATE = .15;//This is the rate for the lowest tip percentage./
            const double MED_TIP_RATE = .18;//This is the rate for the medium tip percentage./
            const double HI_TIP_RATE = .20;//This is the rate for the highest tip percentage./

            userMeal = double.Parse(priceOfMeal.Text);

            lowTip = (userMeal * LOW_TIP_RATE);
            medTip = (userMeal * MED_TIP_RATE);
            hiTip = (userMeal * HI_TIP_RATE);

            lowTipResult.Text = $"{lowTip:C}";
            medTipResult.Text = $"{medTip:C}";
            hiTipResult.Text = $"{hiTip:C}";




        }
    }
}
