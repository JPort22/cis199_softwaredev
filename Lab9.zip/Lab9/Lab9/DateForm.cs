﻿//Grading ID: M4318
//Due Date: 04/23/2019
//CIS 199-01
//Lab 9: Program displays and updates date
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class DateForm : Form
    {
        public DateForm()
        {
            InitializeComponent();
            dateResultLbl.Text = d1.ToString();//
        }
        Date d1 = new Date(1, 1, 2000);//sets d1 for default date using date class

        private void DateForm_Load(object sender, EventArgs e)//loads the data form
        {
            
            dateResultLbl.Text = d1.ToString();
        }


        private void monthUDBtn_Click(object sender, EventArgs e)//button to update the month
        {
            if (int.TryParse(monthTxBx.Text, out int month))
            {
                d1.Month = month;//gets Month property to set month variable inside d1 string
                dateResultLbl.Text = d1.ToString();
            }
            else//error message
                MessageBox.Show("Invalid input!!");
        }

        private void dayUDBtn_Click(object sender, EventArgs e)//button to update day
        {
            if (int.TryParse(dayTxBx.Text, out int day))
            {
                d1.Day = day;//day property used to set day variable inside d1 string
                dateResultLbl.Text = d1.ToString();
            }
            else//error message
                MessageBox.Show("Invalid input!!");
        }

        private void yearUDBtn_Click(object sender, EventArgs e)//button to update the year
        {
            if (int.TryParse(yearTxBx.Text, out int year))
            {
                d1.Year = year;//year property to set year variable inside d1 string
                dateResultLbl.Text = d1.ToString();
            }
            else//error message
                MessageBox.Show("Invalid input!!");

        }

        
    }
}
