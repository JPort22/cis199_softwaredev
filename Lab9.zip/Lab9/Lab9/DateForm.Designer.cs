﻿namespace Lab9
{
    partial class DateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateLbl = new System.Windows.Forms.Label();
            this.dateResultLbl = new System.Windows.Forms.Label();
            this.monthLbl = new System.Windows.Forms.Label();
            this.dayLbl = new System.Windows.Forms.Label();
            this.yearLbl = new System.Windows.Forms.Label();
            this.monthTxBx = new System.Windows.Forms.TextBox();
            this.dayTxBx = new System.Windows.Forms.TextBox();
            this.yearTxBx = new System.Windows.Forms.TextBox();
            this.monthUDBtn = new System.Windows.Forms.Button();
            this.dayUDBtn = new System.Windows.Forms.Button();
            this.yearUDBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Location = new System.Drawing.Point(44, 43);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(56, 20);
            this.dateLbl.TabIndex = 0;
            this.dateLbl.Text = "DATE:";
            // 
            // dateResultLbl
            // 
            this.dateResultLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateResultLbl.Location = new System.Drawing.Point(201, 29);
            this.dateResultLbl.Name = "dateResultLbl";
            this.dateResultLbl.Size = new System.Drawing.Size(151, 34);
            this.dateResultLbl.TabIndex = 1;
            // 
            // monthLbl
            // 
            this.monthLbl.AutoSize = true;
            this.monthLbl.Location = new System.Drawing.Point(44, 97);
            this.monthLbl.Name = "monthLbl";
            this.monthLbl.Size = new System.Drawing.Size(58, 20);
            this.monthLbl.TabIndex = 2;
            this.monthLbl.Text = "Month:";
            // 
            // dayLbl
            // 
            this.dayLbl.AutoSize = true;
            this.dayLbl.Location = new System.Drawing.Point(49, 146);
            this.dayLbl.Name = "dayLbl";
            this.dayLbl.Size = new System.Drawing.Size(41, 20);
            this.dayLbl.TabIndex = 3;
            this.dayLbl.Text = "Day:";
            // 
            // yearLbl
            // 
            this.yearLbl.AutoSize = true;
            this.yearLbl.Location = new System.Drawing.Point(49, 191);
            this.yearLbl.Name = "yearLbl";
            this.yearLbl.Size = new System.Drawing.Size(47, 20);
            this.yearLbl.TabIndex = 4;
            this.yearLbl.Text = "Year:";
            // 
            // monthTxBx
            // 
            this.monthTxBx.Location = new System.Drawing.Point(201, 97);
            this.monthTxBx.Name = "monthTxBx";
            this.monthTxBx.Size = new System.Drawing.Size(100, 26);
            this.monthTxBx.TabIndex = 5;
            // 
            // dayTxBx
            // 
            this.dayTxBx.Location = new System.Drawing.Point(201, 143);
            this.dayTxBx.Name = "dayTxBx";
            this.dayTxBx.Size = new System.Drawing.Size(100, 26);
            this.dayTxBx.TabIndex = 6;
            // 
            // yearTxBx
            // 
            this.yearTxBx.Location = new System.Drawing.Point(201, 188);
            this.yearTxBx.Name = "yearTxBx";
            this.yearTxBx.Size = new System.Drawing.Size(100, 26);
            this.yearTxBx.TabIndex = 7;
            // 
            // monthUDBtn
            // 
            this.monthUDBtn.Location = new System.Drawing.Point(419, 100);
            this.monthUDBtn.Name = "monthUDBtn";
            this.monthUDBtn.Size = new System.Drawing.Size(145, 33);
            this.monthUDBtn.TabIndex = 8;
            this.monthUDBtn.Text = "Update Month";
            this.monthUDBtn.UseVisualStyleBackColor = true;
            this.monthUDBtn.Click += new System.EventHandler(this.monthUDBtn_Click);
            // 
            // dayUDBtn
            // 
            this.dayUDBtn.Location = new System.Drawing.Point(419, 146);
            this.dayUDBtn.Name = "dayUDBtn";
            this.dayUDBtn.Size = new System.Drawing.Size(145, 32);
            this.dayUDBtn.TabIndex = 9;
            this.dayUDBtn.Text = "Update Day";
            this.dayUDBtn.UseVisualStyleBackColor = true;
            this.dayUDBtn.Click += new System.EventHandler(this.dayUDBtn_Click);
            // 
            // yearUDBtn
            // 
            this.yearUDBtn.Location = new System.Drawing.Point(419, 191);
            this.yearUDBtn.Name = "yearUDBtn";
            this.yearUDBtn.Size = new System.Drawing.Size(145, 33);
            this.yearUDBtn.TabIndex = 10;
            this.yearUDBtn.Text = "Update Year";
            this.yearUDBtn.UseVisualStyleBackColor = true;
            this.yearUDBtn.Click += new System.EventHandler(this.yearUDBtn_Click);
            // 
            // DateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.yearUDBtn);
            this.Controls.Add(this.dayUDBtn);
            this.Controls.Add(this.monthUDBtn);
            this.Controls.Add(this.yearTxBx);
            this.Controls.Add(this.dayTxBx);
            this.Controls.Add(this.monthTxBx);
            this.Controls.Add(this.yearLbl);
            this.Controls.Add(this.dayLbl);
            this.Controls.Add(this.monthLbl);
            this.Controls.Add(this.dateResultLbl);
            this.Controls.Add(this.dateLbl);
            this.Name = "DateForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.DateForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Label dateResultLbl;
        private System.Windows.Forms.Label monthLbl;
        private System.Windows.Forms.Label dayLbl;
        private System.Windows.Forms.Label yearLbl;
        private System.Windows.Forms.TextBox monthTxBx;
        private System.Windows.Forms.TextBox dayTxBx;
        private System.Windows.Forms.TextBox yearTxBx;
        private System.Windows.Forms.Button monthUDBtn;
        private System.Windows.Forms.Button dayUDBtn;
        private System.Windows.Forms.Button yearUDBtn;
    }
}

