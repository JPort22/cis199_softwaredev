﻿//Grading ID: M4318
//Due Date: 4/23/2019
//CIS 199-01
//Lab 9: This program creates and shows a Date program.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9
{
    public class Date
    {
        private int _month;//backing field for month variable
        private int _day;//backing field for day variable
        private int _year;//backing field for year variable

        public const int one = 1;//const for the number one
        public const int twelve = 12;//const for month amounts
        public const int  thirtyone = 31;//const for day amounts
        public const int zero = 0;//const for year value
        public const int currentYear = 2019;//current value for year


        public int Month
        {
            //Precondition: None
            //Postcondition: month is returned
            get
            {
                return _month;
            }
            //Precondition: value of month is between and equal to 1 or 12
            //Postcondition: month is set to its specified value
            set
            {
                if (value >= one || value <= twelve)
                    _month = value;
                else //when invalid, set month to one instead
                    _month = one;
            }
        }
        public int Day
        {
            //Precondition: None
            //Postcondition: day is returned
            get
            {
                return _day;
            }
            //Precondition: day is set to be between 1 and 31 and equal as well
            //Postcondition: day is going to be set to specified value
            set
            {
                if (value >= one || value <= thirtyone)
                    _day = value;
                else //when invalid sets day to one instead
                    _day = one;
            }
        }
        public int Year
        {
            //Precondition: None
            //Postcondition: year is returned
            get
            {
                return _year;
            }
            //Precondition: year is automatically equal to or greater than zero
            //Postcondition: year is set to specified value
            set
            {
                if (value >= zero)
                    _year = value;
                else //when invalid sets year to 2019 instead
                    _year = currentYear;
            }
        }
        public Date(int mth, int day, int yar)
        {
            Month = mth;//set using the month property
            Day = day;//set using the day property
            Year = yar;//set using the year property
        }
        public override string ToString()
        {
            string dateResult;//strings date result
            dateResult = $"{Month:D2}/{Day:D2}/{Year:D4}";//uses properties to display resultm 
            return dateResult;//returns the result of the date as a string
            
        }

    }
}
