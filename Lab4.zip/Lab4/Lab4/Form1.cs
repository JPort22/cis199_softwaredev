﻿//Grading ID: M4318
//Date: 2/17/2019
//CIS 199-01
//Lab 4
//The purpose of this program is to calculate whether a student is accepted or rejected and to count the total amount of admission statuses
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
       private int acceptCounter = 0;//This counts the amount of accepted admissions
        private int rejectCounter= 0;//This counts the amount of rejected admissions
        public Form1()
        {
            InitializeComponent();
        }
        //The purpose of this button is to calculate whether a student is admitted based on test score and gpa while also counting the amount of acceptions and rejections for admissions
        private void admissionBtn_Click(object sender, EventArgs e)
        {
            //Variables
            double gpa;//This is the variable for the gpa entered
            int score;//This is the variable for the test score entered
            const double gpaVal = 3.0;//This is the gpa required
            const int lowScore = 60;//This is the minimum value of a score 
            const int hiScore = 80;//This the minimum value of a score 
            //User Input
            if
            (double.TryParse(gpaEntered.Text, out gpa))

                if
                 (int.TryParse(testScoreEntered.Text, out score))

                    if //This displays the output when the user meets the first set of requirements
                        (gpa >= gpaVal && score >= lowScore)
                    {
                        resultOutput.Text = "Accepted";
                        acceptCounter++;
                        acceptOutputAmt.Text = $"{acceptCounter}";
                    }

                    else if//This displays the output when the user meets one set of the requirements

                        (gpa < gpaVal && score >= hiScore)
                    {
                        resultOutput.Text = "Accepted";
                        acceptCounter++;
                        acceptOutputAmt.Text = $"{acceptCounter}";
                    }
                    else//This output displays when the user doesn't meet either requirements
                    {
                        resultOutput.Text = "Rejected";
                        rejectCounter++;
                        rejectOutputAmt.Text = $"{rejectCounter}";
                    }

                else MessageBox.Show("Enter a valid test score");//Error message for invalid test score
            else MessageBox.Show("Enter a valid GPA");//Error message for invalid GPA



        }
    }
}
