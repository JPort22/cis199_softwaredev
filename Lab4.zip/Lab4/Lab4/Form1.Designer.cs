﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaLb = new System.Windows.Forms.Label();
            this.gpaEntered = new System.Windows.Forms.TextBox();
            this.testScoreLb = new System.Windows.Forms.Label();
            this.testScoreEntered = new System.Windows.Forms.TextBox();
            this.admissionBtn = new System.Windows.Forms.Button();
            this.titleLb = new System.Windows.Forms.Label();
            this.resultLb = new System.Windows.Forms.Label();
            this.resultOutput = new System.Windows.Forms.Label();
            this.runningTotalLb = new System.Windows.Forms.Label();
            this.acceptLb = new System.Windows.Forms.Label();
            this.acceptOutputAmt = new System.Windows.Forms.Label();
            this.rejectLb = new System.Windows.Forms.Label();
            this.rejectOutputAmt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpaLb
            // 
            this.gpaLb.AutoSize = true;
            this.gpaLb.Location = new System.Drawing.Point(12, 82);
            this.gpaLb.Name = "gpaLb";
            this.gpaLb.Size = new System.Drawing.Size(43, 20);
            this.gpaLb.TabIndex = 0;
            this.gpaLb.Text = "GPA";
            // 
            // gpaEntered
            // 
            this.gpaEntered.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gpaEntered.Location = new System.Drawing.Point(124, 82);
            this.gpaEntered.Name = "gpaEntered";
            this.gpaEntered.Size = new System.Drawing.Size(100, 19);
            this.gpaEntered.TabIndex = 1;
            // 
            // testScoreLb
            // 
            this.testScoreLb.AutoSize = true;
            this.testScoreLb.Location = new System.Drawing.Point(12, 129);
            this.testScoreLb.Name = "testScoreLb";
            this.testScoreLb.Size = new System.Drawing.Size(86, 20);
            this.testScoreLb.TabIndex = 2;
            this.testScoreLb.Text = "Test Score";
            // 
            // testScoreEntered
            // 
            this.testScoreEntered.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.testScoreEntered.Location = new System.Drawing.Point(124, 129);
            this.testScoreEntered.Name = "testScoreEntered";
            this.testScoreEntered.Size = new System.Drawing.Size(100, 19);
            this.testScoreEntered.TabIndex = 3;
            // 
            // admissionBtn
            // 
            this.admissionBtn.Location = new System.Drawing.Point(490, 115);
            this.admissionBtn.Name = "admissionBtn";
            this.admissionBtn.Size = new System.Drawing.Size(212, 49);
            this.admissionBtn.TabIndex = 4;
            this.admissionBtn.Text = "Did You Get Into College?";
            this.admissionBtn.UseVisualStyleBackColor = true;
            this.admissionBtn.Click += new System.EventHandler(this.admissionBtn_Click);
            // 
            // titleLb
            // 
            this.titleLb.AutoSize = true;
            this.titleLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.titleLb.Location = new System.Drawing.Point(253, 40);
            this.titleLb.Name = "titleLb";
            this.titleLb.Size = new System.Drawing.Size(293, 32);
            this.titleLb.TabIndex = 5;
            this.titleLb.Text = "Univeristy Admissions";
            // 
            // resultLb
            // 
            this.resultLb.AutoSize = true;
            this.resultLb.Location = new System.Drawing.Point(12, 180);
            this.resultLb.Name = "resultLb";
            this.resultLb.Size = new System.Drawing.Size(59, 20);
            this.resultLb.TabIndex = 6;
            this.resultLb.Text = "Result:";
            // 
            // resultOutput
            // 
            this.resultOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultOutput.Location = new System.Drawing.Point(124, 180);
            this.resultOutput.Name = "resultOutput";
            this.resultOutput.Size = new System.Drawing.Size(100, 23);
            this.resultOutput.TabIndex = 7;
            // 
            // runningTotalLb
            // 
            this.runningTotalLb.AutoSize = true;
            this.runningTotalLb.Location = new System.Drawing.Point(12, 229);
            this.runningTotalLb.Name = "runningTotalLb";
            this.runningTotalLb.Size = new System.Drawing.Size(215, 20);
            this.runningTotalLb.TabIndex = 8;
            this.runningTotalLb.Text = "Running Total of Admissions:";
            // 
            // acceptLb
            // 
            this.acceptLb.AutoSize = true;
            this.acceptLb.Location = new System.Drawing.Point(12, 260);
            this.acceptLb.Name = "acceptLb";
            this.acceptLb.Size = new System.Drawing.Size(88, 20);
            this.acceptLb.TabIndex = 9;
            this.acceptLb.Text = "Acceptions";
            // 
            // acceptOutputAmt
            // 
            this.acceptOutputAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptOutputAmt.Location = new System.Drawing.Point(12, 292);
            this.acceptOutputAmt.Name = "acceptOutputAmt";
            this.acceptOutputAmt.Size = new System.Drawing.Size(100, 23);
            this.acceptOutputAmt.TabIndex = 10;
            // 
            // rejectLb
            // 
            this.rejectLb.AutoSize = true;
            this.rejectLb.Location = new System.Drawing.Point(173, 260);
            this.rejectLb.Name = "rejectLb";
            this.rejectLb.Size = new System.Drawing.Size(84, 20);
            this.rejectLb.TabIndex = 11;
            this.rejectLb.Text = "Rejections";
            // 
            // rejectOutputAmt
            // 
            this.rejectOutputAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejectOutputAmt.Location = new System.Drawing.Point(177, 292);
            this.rejectOutputAmt.Name = "rejectOutputAmt";
            this.rejectOutputAmt.Size = new System.Drawing.Size(100, 23);
            this.rejectOutputAmt.TabIndex = 12;
            // 
            // Form1
            // 
            this.AcceptButton = this.admissionBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rejectOutputAmt);
            this.Controls.Add(this.rejectLb);
            this.Controls.Add(this.acceptOutputAmt);
            this.Controls.Add(this.acceptLb);
            this.Controls.Add(this.runningTotalLb);
            this.Controls.Add(this.resultOutput);
            this.Controls.Add(this.resultLb);
            this.Controls.Add(this.titleLb);
            this.Controls.Add(this.admissionBtn);
            this.Controls.Add(this.testScoreEntered);
            this.Controls.Add(this.testScoreLb);
            this.Controls.Add(this.gpaEntered);
            this.Controls.Add(this.gpaLb);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gpaLb;
        private System.Windows.Forms.TextBox gpaEntered;
        private System.Windows.Forms.Label testScoreLb;
        private System.Windows.Forms.TextBox testScoreEntered;
        private System.Windows.Forms.Button admissionBtn;
        private System.Windows.Forms.Label titleLb;
        private System.Windows.Forms.Label resultLb;
        private System.Windows.Forms.Label resultOutput;
        private System.Windows.Forms.Label runningTotalLb;
        private System.Windows.Forms.Label acceptLb;
        private System.Windows.Forms.Label acceptOutputAmt;
        private System.Windows.Forms.Label rejectLb;
        private System.Windows.Forms.Label rejectOutputAmt;
    }
}

