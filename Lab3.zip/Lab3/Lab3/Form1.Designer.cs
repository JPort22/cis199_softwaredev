﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.sphereRadiusLb = new System.Windows.Forms.Label();
            this.radiusSphereTxt = new System.Windows.Forms.TextBox();
            this.diameterSphereLb = new System.Windows.Forms.Label();
            this.diameterOutput = new System.Windows.Forms.Label();
            this.surfaceAreaLb = new System.Windows.Forms.Label();
            this.surfaceAreaOutput = new System.Windows.Forms.Label();
            this.volumeLb = new System.Windows.Forms.Label();
            this.volumeOutput = new System.Windows.Forms.Label();
            this.calcBtn = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // sphereRadiusLb
            // 
            this.sphereRadiusLb.AutoSize = true;
            this.sphereRadiusLb.Location = new System.Drawing.Point(240, 78);
            this.sphereRadiusLb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sphereRadiusLb.Name = "sphereRadiusLb";
            this.sphereRadiusLb.Size = new System.Drawing.Size(134, 20);
            this.sphereRadiusLb.TabIndex = 0;
            this.sphereRadiusLb.Text = "Radius of sphere:";
            // 
            // radiusSphereTxt
            // 
            this.radiusSphereTxt.Location = new System.Drawing.Point(397, 78);
            this.radiusSphereTxt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radiusSphereTxt.Name = "radiusSphereTxt";
            this.radiusSphereTxt.Size = new System.Drawing.Size(148, 26);
            this.radiusSphereTxt.TabIndex = 1;
            // 
            // diameterSphereLb
            // 
            this.diameterSphereLb.AutoSize = true;
            this.diameterSphereLb.Location = new System.Drawing.Point(12, 238);
            this.diameterSphereLb.Name = "diameterSphereLb";
            this.diameterSphereLb.Size = new System.Drawing.Size(74, 20);
            this.diameterSphereLb.TabIndex = 2;
            this.diameterSphereLb.Text = "Diameter";
            // 
            // diameterOutput
            // 
            this.diameterOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.diameterOutput.Location = new System.Drawing.Point(121, 235);
            this.diameterOutput.Name = "diameterOutput";
            this.diameterOutput.Size = new System.Drawing.Size(100, 23);
            this.diameterOutput.TabIndex = 3;
            // 
            // surfaceAreaLb
            // 
            this.surfaceAreaLb.AutoSize = true;
            this.surfaceAreaLb.Location = new System.Drawing.Point(12, 289);
            this.surfaceAreaLb.Name = "surfaceAreaLb";
            this.surfaceAreaLb.Size = new System.Drawing.Size(103, 20);
            this.surfaceAreaLb.TabIndex = 4;
            this.surfaceAreaLb.Text = "Surface Area";
            // 
            // surfaceAreaOutput
            // 
            this.surfaceAreaOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.surfaceAreaOutput.Location = new System.Drawing.Point(121, 286);
            this.surfaceAreaOutput.Name = "surfaceAreaOutput";
            this.surfaceAreaOutput.Size = new System.Drawing.Size(100, 23);
            this.surfaceAreaOutput.TabIndex = 5;
            // 
            // volumeLb
            // 
            this.volumeLb.AutoSize = true;
            this.volumeLb.Location = new System.Drawing.Point(12, 337);
            this.volumeLb.Name = "volumeLb";
            this.volumeLb.Size = new System.Drawing.Size(63, 20);
            this.volumeLb.TabIndex = 6;
            this.volumeLb.Text = "Volume";
            // 
            // volumeOutput
            // 
            this.volumeOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.volumeOutput.Location = new System.Drawing.Point(121, 337);
            this.volumeOutput.Name = "volumeOutput";
            this.volumeOutput.Size = new System.Drawing.Size(100, 23);
            this.volumeOutput.TabIndex = 7;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(417, 127);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(90, 32);
            this.calcBtn.TabIndex = 8;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(397, 289);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(42, 35);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(150, 150);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AcceptButton = this.calcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 555);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.volumeOutput);
            this.Controls.Add(this.volumeLb);
            this.Controls.Add(this.surfaceAreaOutput);
            this.Controls.Add(this.surfaceAreaLb);
            this.Controls.Add(this.diameterOutput);
            this.Controls.Add(this.diameterSphereLb);
            this.Controls.Add(this.radiusSphereTxt);
            this.Controls.Add(this.sphereRadiusLb);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sphereRadiusLb;
        private System.Windows.Forms.TextBox radiusSphereTxt;
        private System.Windows.Forms.Label diameterSphereLb;
        private System.Windows.Forms.Label diameterOutput;
        private System.Windows.Forms.Label surfaceAreaLb;
        private System.Windows.Forms.Label surfaceAreaOutput;
        private System.Windows.Forms.Label volumeLb;
        private System.Windows.Forms.Label volumeOutput;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

