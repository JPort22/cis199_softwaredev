﻿//Grading ID: M4318
//Lab 3
//CIS 199-01
//01/10/2019
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //This button's purpose is to calculate the diameter,surface area, and volume of a sphere.
        private void calcBtn_Click(object sender, EventArgs e)
        {
            //Variables Declared
            double radius;//This is the radius entered by the user.
            double diameter;//This the diameter calculated by the button.
            double surfaceArea; //This is the surface area calculated by the button.
            double volume; //This is the volume calculated by the button.

         //User Input
         radius = double.Parse(radiusSphereTxt.Text);

         //Calculations
         diameter = 2.0 * radius;
         surfaceArea = 4.0 * Math.PI * (radius * radius);
         volume = 4.0 * Math.PI * (radius * radius * radius) / 3.0;

            //Output
            diameterOutput.Text = $"{diameter:F2}";
            surfaceAreaOutput.Text = $"{surfaceArea:F2}";
            volumeOutput.Text = $"{volume:F2}";
        }
    }
}
