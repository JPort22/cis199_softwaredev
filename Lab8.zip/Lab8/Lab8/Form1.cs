﻿//Grading ID: M4318
//Lab 8
//CIS 199-01
//Due Date: 03/31/2019
//The purpose of this lab is to use methods that will calculate investment return of a certain time period
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Pre-condition: button needs to be clicked in order to be run
        //Post-condition: button is clicked and code then runs to gather data and output present Value
        private void calcBtn_Click(object sender, EventArgs e)
        {
            //Declared Variables
            double futureValue;//variable for input future value
            double interestRate;//variable for input rate
            int numYears;//variable for number of years
            double presentValue;//variable for output of present value
            //User Input and Data Validity
            if (double.TryParse(futureValueTxBxInput.Text, out futureValue) && double.TryParse(annInterestRtTxBxInput.Text, out interestRate) && int.TryParse(numYearTxBxInput.Text, out numYears))
            {
                presentValue = CalcPresentValue(futureValue, interestRate, numYears);
                presentValueLbOutput.Text = ($"{presentValue:C}");
            }
            else//error message
            {
                MessageBox.Show("Enter valid numbers!");
            }
            

        }
        //Pre-Conditions: The method of CalcPresentValue uses declared positive variables to calculate
        //the desired result using a double type for the future value, a double type for the rate of the investment
        //Post-Condition: Calculates present value and returns it for output
        private static double CalcPresentValue(double futVal, double rate, int year)
        {
            double presentValue;
            presentValue = futVal / Math.Pow(1 + rate, year);
            return presentValue;
            
        }
    }
}
