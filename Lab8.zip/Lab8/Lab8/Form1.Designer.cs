﻿namespace Lab8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.futureValueLb = new System.Windows.Forms.Label();
            this.futureValueTxBxInput = new System.Windows.Forms.TextBox();
            this.annInterestRtLb = new System.Windows.Forms.Label();
            this.annInterestRtTxBxInput = new System.Windows.Forms.TextBox();
            this.numYearsLb = new System.Windows.Forms.Label();
            this.numYearTxBxInput = new System.Windows.Forms.TextBox();
            this.presentValueLb = new System.Windows.Forms.Label();
            this.presentValueLbOutput = new System.Windows.Forms.Label();
            this.calcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // futureValueLb
            // 
            this.futureValueLb.AutoSize = true;
            this.futureValueLb.Location = new System.Drawing.Point(33, 50);
            this.futureValueLb.Name = "futureValueLb";
            this.futureValueLb.Size = new System.Drawing.Size(105, 20);
            this.futureValueLb.TabIndex = 0;
            this.futureValueLb.Text = "Future Value:";
            // 
            // futureValueTxBxInput
            // 
            this.futureValueTxBxInput.Location = new System.Drawing.Point(200, 50);
            this.futureValueTxBxInput.Name = "futureValueTxBxInput";
            this.futureValueTxBxInput.Size = new System.Drawing.Size(100, 26);
            this.futureValueTxBxInput.TabIndex = 1;
            // 
            // annInterestRtLb
            // 
            this.annInterestRtLb.AutoSize = true;
            this.annInterestRtLb.Location = new System.Drawing.Point(33, 103);
            this.annInterestRtLb.Name = "annInterestRtLb";
            this.annInterestRtLb.Size = new System.Drawing.Size(161, 20);
            this.annInterestRtLb.TabIndex = 2;
            this.annInterestRtLb.Text = "Annual Interest Rate:";
            // 
            // annInterestRtTxBxInput
            // 
            this.annInterestRtTxBxInput.Location = new System.Drawing.Point(200, 103);
            this.annInterestRtTxBxInput.Name = "annInterestRtTxBxInput";
            this.annInterestRtTxBxInput.Size = new System.Drawing.Size(100, 26);
            this.annInterestRtTxBxInput.TabIndex = 3;
            // 
            // numYearsLb
            // 
            this.numYearsLb.AutoSize = true;
            this.numYearsLb.Location = new System.Drawing.Point(33, 158);
            this.numYearsLb.Name = "numYearsLb";
            this.numYearsLb.Size = new System.Drawing.Size(111, 20);
            this.numYearsLb.TabIndex = 4;
            this.numYearsLb.Text = "No. of Year(s):";
            // 
            // numYearTxBxInput
            // 
            this.numYearTxBxInput.Location = new System.Drawing.Point(200, 158);
            this.numYearTxBxInput.Name = "numYearTxBxInput";
            this.numYearTxBxInput.Size = new System.Drawing.Size(100, 26);
            this.numYearTxBxInput.TabIndex = 5;
            // 
            // presentValueLb
            // 
            this.presentValueLb.AutoSize = true;
            this.presentValueLb.Location = new System.Drawing.Point(33, 222);
            this.presentValueLb.Name = "presentValueLb";
            this.presentValueLb.Size = new System.Drawing.Size(113, 20);
            this.presentValueLb.TabIndex = 6;
            this.presentValueLb.Text = "Present Value:";
            // 
            // presentValueLbOutput
            // 
            this.presentValueLbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.presentValueLbOutput.Location = new System.Drawing.Point(200, 212);
            this.presentValueLbOutput.Name = "presentValueLbOutput";
            this.presentValueLbOutput.Size = new System.Drawing.Size(125, 30);
            this.presentValueLbOutput.TabIndex = 7;
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(442, 135);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(148, 72);
            this.calcBtn.TabIndex = 8;
            this.calcBtn.Text = "Calculate";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calcBtn);
            this.Controls.Add(this.presentValueLbOutput);
            this.Controls.Add(this.presentValueLb);
            this.Controls.Add(this.numYearTxBxInput);
            this.Controls.Add(this.numYearsLb);
            this.Controls.Add(this.annInterestRtTxBxInput);
            this.Controls.Add(this.annInterestRtLb);
            this.Controls.Add(this.futureValueTxBxInput);
            this.Controls.Add(this.futureValueLb);
            this.Name = "Form1";
            this.Text = "Lab8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label futureValueLb;
        private System.Windows.Forms.TextBox futureValueTxBxInput;
        private System.Windows.Forms.Label annInterestRtLb;
        private System.Windows.Forms.TextBox annInterestRtTxBxInput;
        private System.Windows.Forms.Label numYearsLb;
        private System.Windows.Forms.TextBox numYearTxBxInput;
        private System.Windows.Forms.Label presentValueLb;
        private System.Windows.Forms.Label presentValueLbOutput;
        private System.Windows.Forms.Button calcBtn;
    }
}

