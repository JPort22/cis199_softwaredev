﻿//Grading ID: M4318
//Due Date: 04/23/2019
//CIS 199-01
//Program 4 has the purpose of finding information for ground packages for a parcel service.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class GroundPackage
    {
        //backing fields for package information
        private int _zipCode;//origin zip code for package
        private int _destZipCode;//destination zip code for package
        private double _length;//length of package
        private double _width;//width of package
        private double _height;//height of package
        private double _weight;//weight of package
        private int _zoneDistance;//zone distance is difference between 1 digits in zip code
        //constant numbers needed for validation and testing
        public const int zipThresOne = 00000;//start of the zip code threshold
        public const int zipThresTwo = 99999;//end of the zip code threshold
        public const int zipDefault = 40202;//default for origin zip code if error
        public const int destZipCodeDefault = 90210;//default for destination zip code
        public const int zero = 0;//constant variable for zero
        public const double defaultMeasurement = 1.0;//default measurements for package size
        public const int zipTenCalc = 10000;//number needed for calculation
        public int zoneDistPartO;//variable needed for zone distance calculation
        public int zoneDistPartT;//variable needed for zone distance calculation
        //Precondition: parameters need to be met, as shown below
        //Postcondition: a ground package object is created
        public GroundPackage(int org, int dest, double len, double wid, double hei, double wei)
        {
            OriginZip = org;
            DestinationZip = dest;
            Length = len;
            Width = wid;
            Height = hei;
            Weight = wei;
        }

        

        public int OriginZip//origin zip property 
        {
            //Precondition: None
            //Postconditon: returns origin zip code
            get
            {
                return _zipCode;
            }
            //Precondition: value of origin zip is set to be or be between 00000 and 99999
            //Postcondition: setting origin zip code to specified value
            set
            {
                if (value >= zipThresOne && value <= zipThresTwo)
                    _zipCode = value;
                else//if error sets default
                    _zipCode = zipDefault;
            }
        }
        public int DestinationZip//destination zip property
        {
            //Precondition: None
            //Postcondition: destination zip is returned
            get
            {
                return _destZipCode;
            }
            //Precondition: value of destination zip is set to be or be between 00000 and 99999
            //Postcondition: destination zip is set to specified value
            set
            {
                if (value >= zipThresOne && value <= zipThresTwo)
                    _destZipCode = value;
                else//if error sets default
                    _destZipCode = destZipCodeDefault;
            }

        }
        public double Length//length property
        {
            //Precondition: None
            //Postcondition: returns length of package
            get
            {
                return _length;
            }
            //Precondition: value of length is greater than 0
            //Postcondition: sets length specified value
            set
            {
                if (value > zero)
                    _length = value;
                else//if error sets default
                    _length = defaultMeasurement;
            }
        }
        public double Width//width property
        {
            //Precondition: none
            //Postcondition: returns width of package
            get
            {
                return _width;
            }
            //Precondition: width value is greater than 0
            //Postcondition: width is set to specified value
            set
            {
                if (value > zero)
                    _width = value;
                else//if error sets default
                    _width = defaultMeasurement;
            }
        }
        public double Height//height property
        {
            //Precondition: None
            //Postcondition: returns package height
            get
            {
                return _height;
            }
            //Precondition: height is to be greater than 0
            //Postcondition: height is set to specified value
            set
            {
                if (value > zero)
                    _height = value;
                else//if error sets a default
                    _height = defaultMeasurement;
            }
        }
        public double Weight//weight property
        {
            //Precondition: None
            //Postcondition: returns package weight
            get
            {
                return _weight;
            }
            //Precondition: weight is to be greater than 0
            //Postcondition: weight is set to specified value
            set
            {
                if (value > zero)
                    _weight = value;
                else//if error sets default
                    _weight = defaultMeasurement;
            }
        }
        public int ZoneDistance
        {//calculations and such for zone distance
            get
            {
                zoneDistPartO = _zipCode / zipTenCalc;
                zoneDistPartT = _destZipCode / zipTenCalc;
                _zoneDistance = Math.Abs(zoneDistPartO - zoneDistPartT);
                return _zoneDistance;

            }
        }
        public double CalcCost()
        {//calculation for cost of package
            double cost;
            const double SIZE_COST_FACTOR = .25;//variable for size of package cost
            const double WEIGHT_COST_FACTOR = .45;//variable for weight of package cost
            cost = SIZE_COST_FACTOR * (Length + Width + Height) + WEIGHT_COST_FACTOR * (ZoneDistance + 1) * (Weight);
            return cost;
        }
        //Output Results
        public override string ToString()
        {
            string result;
            result = $"  Origin Zip Code:{OriginZip}{Environment.NewLine}"
                + $"  Destination Zip Code: {DestinationZip}{Environment.NewLine}"
                + $"  Length: {Length} inches {Environment.NewLine}"
                + $"  Width:  {Width} inches {Environment.NewLine}"
                + $"  Height: {Height} inches {Environment.NewLine}"
                + $"  Weight: {Weight} inches {Environment.NewLine}"
                + $"  Zone Distance: {ZoneDistance}{Environment.NewLine}";
            return result;

        }
    }
}
