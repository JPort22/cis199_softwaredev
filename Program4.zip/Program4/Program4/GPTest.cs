﻿//Grading ID: M4318
//CIS 199-01
//Due Date: 04/23/2019
//Program 4 is a console app with the purpose of giving and receiving package information.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    public class GPTest
    {
        public static void Main(string[] args)
        {
            GroundPackage gpack1 = new GroundPackage(40299, 40205, 1.3, 1.3, 1.3, 5.3);//array for first package info
            GroundPackage gpack2 = new GroundPackage(40299, 70210, 10.5, 11.5, 12.5, 20.2);//array for second package info
            GroundPackage gpack3 = new GroundPackage(20478, 67890, 4.3, 3.7, 6.7, 28.6);//array for third package info
            GroundPackage gpack4 = new GroundPackage(37562, 90211, 4.4, 2.8, 3.5, 12.8);//array for fourth package info
            GroundPackage gpack5 = new GroundPackage(-1, -1, 0.0, 0.0, 0.0, 0.0);//array with invalid data for package test

            GroundPackage[] packArray = { gpack1, gpack2, gpack3, gpack4, gpack5 };//making all packages and putting them in array for checking

            WriteLine("Original Package Data:");
            DisplayPackages(packArray);
            //changes made to packages listed above
            gpack1.DestinationZip = 65489;
            gpack2.OriginZip = 12078;
            gpack2.Length = 10.3;
            gpack3.Width = 4.3;
            gpack3.Weight = 12.3;
            gpack4.Width = 2.7;
            gpack4.Weight = 14.5;
            gpack5.OriginZip = 40255;
            gpack5.DestinationZip = 56720;
            gpack5.Length = 1.5;
            gpack5.Width = 2.8;
            gpack5.Height = 7.3;
            gpack5.Weight = 4.8;

            WriteLine("New Package Data:");
            DisplayPackages(packArray);//displays packArray in New Package Data


        }
        public static void DisplayPackages(GroundPackage[] packArray)
        {//uses for loop to calculate cost for package dimensions and weight to display
            for (int x = 0; x < packArray.Length; ++x)
            {
                WriteLine($"Package # {x + 1}");
                Write($"{packArray[x].ToString()}");
                WriteLine($" Cost:{packArray[x].CalcCost():C}");
                WriteLine();
            }
        }
        
    }
}
