﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.taxableIncomeLb = new System.Windows.Forms.Label();
            this.taxableIncomeTx = new System.Windows.Forms.TextBox();
            this.singleRadioBtn = new System.Windows.Forms.RadioButton();
            this.marriedFilingJointRadioBtn = new System.Windows.Forms.RadioButton();
            this.hOfHouseRadioBtn = new System.Windows.Forms.RadioButton();
            this.marriedFilingSepRadioBtn = new System.Windows.Forms.RadioButton();
            this.marginalIncomeTaxRateLb = new System.Windows.Forms.Label();
            this.marginalIncomeTaxRateLbOutput = new System.Windows.Forms.Label();
            this.incomeTaxAmtDueLb = new System.Windows.Forms.Label();
            this.incomeTaxAmtDueLbOutput = new System.Windows.Forms.Label();
            this.taxFormsTitle = new System.Windows.Forms.Label();
            this.calcTaxBtn = new System.Windows.Forms.Button();
            this.filingStatusGroupBx = new System.Windows.Forms.GroupBox();
            this.filingStatusGroupBx.SuspendLayout();
            this.SuspendLayout();
            // 
            // taxableIncomeLb
            // 
            this.taxableIncomeLb.AutoSize = true;
            this.taxableIncomeLb.Location = new System.Drawing.Point(12, 113);
            this.taxableIncomeLb.Name = "taxableIncomeLb";
            this.taxableIncomeLb.Size = new System.Drawing.Size(168, 20);
            this.taxableIncomeLb.TabIndex = 0;
            this.taxableIncomeLb.Text = "Enter Taxable Income:";
            // 
            // taxableIncomeTx
            // 
            this.taxableIncomeTx.Location = new System.Drawing.Point(186, 107);
            this.taxableIncomeTx.Name = "taxableIncomeTx";
            this.taxableIncomeTx.Size = new System.Drawing.Size(149, 26);
            this.taxableIncomeTx.TabIndex = 1;
            // 
            // singleRadioBtn
            // 
            this.singleRadioBtn.AutoSize = true;
            this.singleRadioBtn.Checked = true;
            this.singleRadioBtn.Location = new System.Drawing.Point(139, 25);
            this.singleRadioBtn.Name = "singleRadioBtn";
            this.singleRadioBtn.Size = new System.Drawing.Size(78, 24);
            this.singleRadioBtn.TabIndex = 2;
            this.singleRadioBtn.TabStop = true;
            this.singleRadioBtn.Text = "Single";
            this.singleRadioBtn.UseVisualStyleBackColor = true;
            // 
            // marriedFilingJointRadioBtn
            // 
            this.marriedFilingJointRadioBtn.AutoSize = true;
            this.marriedFilingJointRadioBtn.Location = new System.Drawing.Point(139, 55);
            this.marriedFilingJointRadioBtn.Name = "marriedFilingJointRadioBtn";
            this.marriedFilingJointRadioBtn.Size = new System.Drawing.Size(176, 24);
            this.marriedFilingJointRadioBtn.TabIndex = 3;
            this.marriedFilingJointRadioBtn.Text = "Married Filing Jointly";
            this.marriedFilingJointRadioBtn.UseVisualStyleBackColor = true;
            // 
            // hOfHouseRadioBtn
            // 
            this.hOfHouseRadioBtn.AutoSize = true;
            this.hOfHouseRadioBtn.Location = new System.Drawing.Point(139, 85);
            this.hOfHouseRadioBtn.Name = "hOfHouseRadioBtn";
            this.hOfHouseRadioBtn.Size = new System.Drawing.Size(172, 24);
            this.hOfHouseRadioBtn.TabIndex = 4;
            this.hOfHouseRadioBtn.Text = "Head of Household";
            this.hOfHouseRadioBtn.UseVisualStyleBackColor = true;
            // 
            // marriedFilingSepRadioBtn
            // 
            this.marriedFilingSepRadioBtn.AutoSize = true;
            this.marriedFilingSepRadioBtn.Location = new System.Drawing.Point(139, 115);
            this.marriedFilingSepRadioBtn.Name = "marriedFilingSepRadioBtn";
            this.marriedFilingSepRadioBtn.Size = new System.Drawing.Size(208, 24);
            this.marriedFilingSepRadioBtn.TabIndex = 5;
            this.marriedFilingSepRadioBtn.Text = "Married Filing Separately";
            this.marriedFilingSepRadioBtn.UseVisualStyleBackColor = true;
            // 
            // marginalIncomeTaxRateLb
            // 
            this.marginalIncomeTaxRateLb.AutoSize = true;
            this.marginalIncomeTaxRateLb.Location = new System.Drawing.Point(12, 301);
            this.marginalIncomeTaxRateLb.Name = "marginalIncomeTaxRateLb";
            this.marginalIncomeTaxRateLb.Size = new System.Drawing.Size(198, 20);
            this.marginalIncomeTaxRateLb.TabIndex = 6;
            this.marginalIncomeTaxRateLb.Text = "Marginal Income Tax Rate:";
            // 
            // marginalIncomeTaxRateLbOutput
            // 
            this.marginalIncomeTaxRateLbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.marginalIncomeTaxRateLbOutput.Location = new System.Drawing.Point(223, 289);
            this.marginalIncomeTaxRateLbOutput.Name = "marginalIncomeTaxRateLbOutput";
            this.marginalIncomeTaxRateLbOutput.Size = new System.Drawing.Size(197, 32);
            this.marginalIncomeTaxRateLbOutput.TabIndex = 7;
            // 
            // incomeTaxAmtDueLb
            // 
            this.incomeTaxAmtDueLb.AutoSize = true;
            this.incomeTaxAmtDueLb.Location = new System.Drawing.Point(12, 356);
            this.incomeTaxAmtDueLb.Name = "incomeTaxAmtDueLb";
            this.incomeTaxAmtDueLb.Size = new System.Drawing.Size(189, 20);
            this.incomeTaxAmtDueLb.TabIndex = 8;
            this.incomeTaxAmtDueLb.Text = "Income Tax Amount Due:";
            // 
            // incomeTaxAmtDueLbOutput
            // 
            this.incomeTaxAmtDueLbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.incomeTaxAmtDueLbOutput.Location = new System.Drawing.Point(223, 343);
            this.incomeTaxAmtDueLbOutput.Name = "incomeTaxAmtDueLbOutput";
            this.incomeTaxAmtDueLbOutput.Size = new System.Drawing.Size(188, 33);
            this.incomeTaxAmtDueLbOutput.TabIndex = 9;
            // 
            // taxFormsTitle
            // 
            this.taxFormsTitle.AutoSize = true;
            this.taxFormsTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.taxFormsTitle.Location = new System.Drawing.Point(264, 28);
            this.taxFormsTitle.Name = "taxFormsTitle";
            this.taxFormsTitle.Size = new System.Drawing.Size(219, 32);
            this.taxFormsTitle.TabIndex = 10;
            this.taxFormsTitle.Text = "Tax 2019 Forms";
            // 
            // calcTaxBtn
            // 
            this.calcTaxBtn.Location = new System.Drawing.Point(546, 298);
            this.calcTaxBtn.Name = "calcTaxBtn";
            this.calcTaxBtn.Size = new System.Drawing.Size(130, 69);
            this.calcTaxBtn.TabIndex = 11;
            this.calcTaxBtn.Text = "Calculate Tax!!";
            this.calcTaxBtn.UseVisualStyleBackColor = true;
            this.calcTaxBtn.Click += new System.EventHandler(this.calcTaxBtn_Click);
            // 
            // filingStatusGroupBx
            // 
            this.filingStatusGroupBx.Controls.Add(this.singleRadioBtn);
            this.filingStatusGroupBx.Controls.Add(this.marriedFilingJointRadioBtn);
            this.filingStatusGroupBx.Controls.Add(this.hOfHouseRadioBtn);
            this.filingStatusGroupBx.Controls.Add(this.marriedFilingSepRadioBtn);
            this.filingStatusGroupBx.Location = new System.Drawing.Point(407, 102);
            this.filingStatusGroupBx.Name = "filingStatusGroupBx";
            this.filingStatusGroupBx.Size = new System.Drawing.Size(371, 159);
            this.filingStatusGroupBx.TabIndex = 12;
            this.filingStatusGroupBx.TabStop = false;
            this.filingStatusGroupBx.Text = "Check Filing Status:";
            // 
            // Form1
            // 
            this.AcceptButton = this.calcTaxBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.filingStatusGroupBx);
            this.Controls.Add(this.calcTaxBtn);
            this.Controls.Add(this.taxFormsTitle);
            this.Controls.Add(this.incomeTaxAmtDueLbOutput);
            this.Controls.Add(this.incomeTaxAmtDueLb);
            this.Controls.Add(this.marginalIncomeTaxRateLbOutput);
            this.Controls.Add(this.marginalIncomeTaxRateLb);
            this.Controls.Add(this.taxableIncomeTx);
            this.Controls.Add(this.taxableIncomeLb);
            this.Name = "Form1";
            this.Text = "Form1";
            this.filingStatusGroupBx.ResumeLayout(false);
            this.filingStatusGroupBx.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label taxableIncomeLb;
        private System.Windows.Forms.TextBox taxableIncomeTx;
        private System.Windows.Forms.RadioButton singleRadioBtn;
        private System.Windows.Forms.RadioButton marriedFilingJointRadioBtn;
        private System.Windows.Forms.RadioButton hOfHouseRadioBtn;
        private System.Windows.Forms.RadioButton marriedFilingSepRadioBtn;
        private System.Windows.Forms.Label marginalIncomeTaxRateLb;
        private System.Windows.Forms.Label marginalIncomeTaxRateLbOutput;
        private System.Windows.Forms.Label incomeTaxAmtDueLb;
        private System.Windows.Forms.Label incomeTaxAmtDueLbOutput;
        private System.Windows.Forms.Label taxFormsTitle;
        private System.Windows.Forms.Button calcTaxBtn;
        private System.Windows.Forms.GroupBox filingStatusGroupBx;
    }
}

