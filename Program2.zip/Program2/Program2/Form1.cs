﻿//Grading ID:M4318
//Due Date: 03/05/2019
//Program 2
//CIS 199-01
//The purpose of this program is to calculate taxes based on inputs from a user
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        //All constant rates for calculations and marginal tax rate labels
        const double BAR_ONE = .10;//lowest rate
        const double BAR_TWO = .12;//second lowest rate
        const double BAR_THR = .22;// third lowest rate
        const double BAR_FOU = .24;// medium rate
        const double BAR_FIV = .32;//third highest rate
        const double BAR_SIX = .35;//second highest rate
        const double BAR_SEV = .37;//highest rate
        public Form1()
        {
            InitializeComponent();
        }

        private void calcTaxBtn_Click(object sender, EventArgs e)
        {
            //Variables Declared
            int taxableIncome;//variable for entered taxable income
            double taxesDue=0;//variable for taxes due calculation
            double rate=0;//variable for marginal rate reached 
            double zero = 0;//variable used for error message validation
            int bracketOne = 0;//variable used for one time calculation and lowest range
            int bracketTwo = 0;//variable used for calculation and second lowest range
            int bracketThr = 0;//variable used for calculation and middle range
            int bracketFou = 0;//variable used for calculation and third highest range
            int bracketFiv = 0;//variable used for calculation and second highest range
            int bracketSix = 0;//variable used for calculation and highest range
            
            //User Input
            if (int.TryParse(taxableIncomeTx.Text, out taxableIncome))
            {
                if (taxableIncome >= zero)//validation for error message and message box
                {


                    //All conditions for filing status single starting from highest bracket to lowest along with calculations
                    if (singleRadioBtn.Checked)
                    {
                        const int sinHi = 510300;//highest bracket for single
                        const int sinSecHi = 204100;//second highest for single
                        const int sinThrHi = 160725;//third highest bracket
                        const int sinMid = 84200;//mid bracket
                        const int sinSecLo = 39475;//second lowest bracket
                        const int sinLo = 9700;//lowest bracket

                        //giving the brackets assignments for the ranges
                        bracketSix = sinHi;
                        bracketFiv = sinSecHi;
                        bracketFou = sinThrHi;
                        bracketThr = sinMid;
                        bracketTwo = sinSecLo;
                        bracketOne = sinLo;
                       
                    }
                    //Married Filing Jointly button conditions starting from highest bracket to lowest along with calculations
                    if(marriedFilingJointRadioBtn.Checked)
                    {
                        const int mFjHi = 612350;//highest bracket for married filing jointly
                        const int mFjSecHi = 408200;//second highest bracket for married filing jointly
                        const int mFjThrHi = 321450;//third highest bracket
                        const int mFjMid = 168400;//mid bracket
                        const int mFjSecLo = 78950;//second lowest bracket
                        const int mFjLo = 19400;//lowest bracket

                        //giving assignments from ranges in filing status to bracket variables
                        bracketSix = mFjHi;
                        bracketFiv = mFjSecHi;
                        bracketFou = mFjThrHi;
                        bracketThr = mFjMid;
                        bracketTwo = mFjSecLo;
                        bracketOne = mFjLo;
                    }
                    if (hOfHouseRadioBtn.Checked)//head of household conditions for radio button
                    {
                        const int hOhHi = 510300;//highest bracket for head of household
                        const int hOhSecHi = 204100;//second highest bracket for head of household
                        const int hOhThrHi = 160700;//third highest bracket
                        const int hOhMid = 84200;//mid bracket
                        const int hOhSecLo = 52850;//second lowest bracket
                        const int hOhLo = 13850;//lowest bracket

                        //giving assignments to filing statuses through brackets
                        bracketSix = hOhHi;
                        bracketFiv = hOhSecHi;
                        bracketFou = hOhThrHi;
                        bracketThr = hOhMid;
                        bracketTwo = hOhSecLo;
                        bracketOne = hOhLo;
                    }
                    if (marriedFilingSepRadioBtn.Checked)//conditions for married filing separately radio button
                    {
                        const int mFsHi = 306175;//highest bracket for married filing separately
                        const int mFsSecHi = 204100;//second highest bracket for married filing separately
                        const int mFsThrHi = 160725;//third highest bracket
                        const int mFsMid = 84200;//mid bracket
                        const int mFsSecLo = 39475;//second highest bracket
                        const int mFsLo = 9700;//lowest bracket

                        //giving assignments to filing status ranges to bracket variables
                        bracketSix = mFsHi;
                        bracketFiv = mFsSecHi;
                        bracketFou = mFsThrHi;
                        bracketThr = mFsMid;
                        bracketTwo = mFsSecLo;
                        bracketOne = mFsLo;
                    }
                    //validation for ranges along with needed calculations
                    if (taxableIncome > bracketSix)
                    {
                        rate = BAR_SEV;
                        taxesDue = bracketOne * BAR_ONE + (bracketTwo - bracketOne) * BAR_TWO + (bracketThr - bracketTwo) * BAR_THR + (bracketFou - bracketThr) * BAR_FOU + (bracketFiv - bracketFou) * BAR_FIV + (bracketSix - bracketFiv) * BAR_SIX + (taxableIncome - bracketSix) * BAR_SEV;
                    }
                    else if (taxableIncome >= bracketFiv)
                    {
                        rate = BAR_SIX;
                        taxesDue = bracketOne * BAR_ONE + (bracketTwo - bracketOne) * BAR_TWO + (bracketThr - bracketTwo) * BAR_THR + (bracketFou - bracketThr) * BAR_FOU + (bracketFiv - bracketFou) * BAR_FIV + (taxableIncome - bracketFiv) * BAR_SIX;
                    }
                    else if (taxableIncome >= bracketFou)
                    {
                        rate = BAR_FIV;
                        taxesDue = bracketOne * BAR_ONE + (bracketTwo - bracketOne) * BAR_TWO + (bracketThr - bracketTwo) * BAR_THR + (bracketFou - bracketThr) * BAR_FOU + (taxableIncome - bracketFou) * BAR_FIV;
                    }
                    else if (taxableIncome >= bracketThr)
                    {
                        rate = BAR_FOU;
                        taxesDue = bracketOne * BAR_ONE + (bracketTwo - bracketOne) * BAR_TWO + (bracketThr - bracketTwo) * BAR_THR + (taxableIncome - bracketThr) * BAR_FOU;
                    }
                    else if (taxableIncome >= bracketTwo)
                    {
                        rate = BAR_THR;
                        taxesDue = bracketOne * BAR_ONE + (bracketTwo - bracketOne) * BAR_TWO + (taxableIncome - bracketTwo) * BAR_THR;
                    }
                    else if (taxableIncome >= bracketOne)
                    {
                        rate = BAR_TWO;
                        taxesDue = bracketOne * BAR_ONE + (taxableIncome - bracketOne) * BAR_TWO;

                    }
                    else
                    {
                        rate = BAR_ONE;
                        taxesDue = taxableIncome * BAR_ONE;
                    }

                    //Output
                    marginalIncomeTaxRateLbOutput.Text = ($"{rate:P0}");
                    incomeTaxAmtDueLbOutput.Text = ($"{taxesDue:C}");
                }//error messages below for mistakes in user input
                else MessageBox.Show("Enter a positive income.");
            }

            else MessageBox.Show("Please enter a valid income.");
        }
    }

}
