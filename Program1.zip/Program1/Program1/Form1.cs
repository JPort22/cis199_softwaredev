﻿//Grading ID: M4318
//Due Date:2/12/2019
//CIS 199-01
//Program 1
//The purpose of this program is to estimate carpet installation costs for home owners
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //The purpose of this button is to calculate all components used for estimating cost of carpet
        private void estimatorCalcBtn_Click(object sender, EventArgs e)
        {
            //Variables Declared
            double maxWidth;//This is the max width entered by the user
            double maxLength;//This is the max length entered by the user
            double carpetPrice;//This is the carpet price entered by the user
            int layersPad;//This is the amount of padding needed by the user
            int firstRm;//This is the confirmation on whether it is the first room for carpet or not
            const int FST_RM = 100;//This is the added amount of 100 dollars if the first room is worked on
            double costCarpet;//This is the result of the components to get the cost of the carpet
            double costPadding;//This is the result of the components to get the cost of padding
            double costLabor;//This is the result of the components to get the cost of labor
            double totalCost;//This is the total cost produced by adding the cost of all other products
            const double WASTE_RATE = 1.10;//This is the rate for the excess waste
            double surfaceAreaSqFeet;//This is the surface area needed for calculation to get amount in yards
            double totalCarpetSizeYds;//This is the calculated amount of square yards using other calculations
            const double PADDING_COST = 2.75;//This is the cost for padding per square yard
            const double LABOR_COST = 4.50;//This is the cost for labor per square yard
            const double YARD_CHN = 9.0;//This is the yard converter number
            //User Input
            maxWidth = double.Parse(maxWidthEnteredTx.Text);
            maxLength = double.Parse(maxLengthEnteredTx.Text);
            carpetPrice = double.Parse(carpetPriceEnteredTx.Text);
            layersPad = int.Parse(layersPaddingEnteredTx.Text);
            firstRm = int.Parse(firstRoomQTx.Text);
            //Calculations
            surfaceAreaSqFeet = maxWidth * maxLength;
            totalCarpetSizeYds = surfaceAreaSqFeet / YARD_CHN;
            costCarpet = totalCarpetSizeYds * carpetPrice * WASTE_RATE;
            costPadding = layersPad * totalCarpetSizeYds * PADDING_COST * WASTE_RATE;
            if (firstRm == 0)
                costLabor = LABOR_COST * totalCarpetSizeYds;
            else
            {
                costLabor = (LABOR_COST * totalCarpetSizeYds) + FST_RM;
            }

            totalCost = costCarpet + costPadding + costLabor;
           //Output
            sqYardsNeededOutput.Text = $"{totalCarpetSizeYds:F1}";
            carpetCostOutput.Text = $"{costCarpet:C}";
            paddingCostOutput.Text = $"{costPadding:C}";
            laborCostOutput.Text = $"{costLabor:C}";
            totalCostOutput.Text = $"{totalCost:C}";

        }
    }
}
