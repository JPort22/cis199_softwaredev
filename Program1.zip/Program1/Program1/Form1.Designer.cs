﻿namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleProgram = new System.Windows.Forms.Label();
            this.maxWidthLb = new System.Windows.Forms.Label();
            this.maxWidthEnteredTx = new System.Windows.Forms.TextBox();
            this.maxLengthLb = new System.Windows.Forms.Label();
            this.maxLengthEnteredTx = new System.Windows.Forms.TextBox();
            this.carpetPriceLb = new System.Windows.Forms.Label();
            this.carpetPriceEnteredTx = new System.Windows.Forms.TextBox();
            this.layersPaddingLb = new System.Windows.Forms.Label();
            this.layersPaddingEnteredTx = new System.Windows.Forms.TextBox();
            this.firstRoomQLb = new System.Windows.Forms.Label();
            this.firstRoomQTx = new System.Windows.Forms.TextBox();
            this.sqYardsNeededLb = new System.Windows.Forms.Label();
            this.sqYardsNeededOutput = new System.Windows.Forms.Label();
            this.carpetCostLb = new System.Windows.Forms.Label();
            this.carpetCostOutput = new System.Windows.Forms.Label();
            this.paddingCostLb = new System.Windows.Forms.Label();
            this.paddingCostOutput = new System.Windows.Forms.Label();
            this.laborCostLb = new System.Windows.Forms.Label();
            this.laborCostOutput = new System.Windows.Forms.Label();
            this.totalCostLb = new System.Windows.Forms.Label();
            this.totalCostOutput = new System.Windows.Forms.Label();
            this.estimatorCalcBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleProgram
            // 
            this.titleProgram.AutoSize = true;
            this.titleProgram.Location = new System.Drawing.Point(12, 9);
            this.titleProgram.Name = "titleProgram";
            this.titleProgram.Size = new System.Drawing.Size(345, 20);
            this.titleProgram.TabIndex = 0;
            this.titleProgram.Text = "Welcome to the Handy-Dandy Carpet Estimator";
            // 
            // maxWidthLb
            // 
            this.maxWidthLb.AutoSize = true;
            this.maxWidthLb.Location = new System.Drawing.Point(12, 64);
            this.maxWidthLb.Name = "maxWidthLb";
            this.maxWidthLb.Size = new System.Drawing.Size(269, 20);
            this.maxWidthLb.TabIndex = 1;
            this.maxWidthLb.Text = "Enter the max width of room (in feet):";
            // 
            // maxWidthEnteredTx
            // 
            this.maxWidthEnteredTx.Location = new System.Drawing.Point(287, 64);
            this.maxWidthEnteredTx.Name = "maxWidthEnteredTx";
            this.maxWidthEnteredTx.Size = new System.Drawing.Size(100, 26);
            this.maxWidthEnteredTx.TabIndex = 2;
            // 
            // maxLengthLb
            // 
            this.maxLengthLb.AutoSize = true;
            this.maxLengthLb.Location = new System.Drawing.Point(12, 100);
            this.maxLengthLb.Name = "maxLengthLb";
            this.maxLengthLb.Size = new System.Drawing.Size(276, 20);
            this.maxLengthLb.TabIndex = 3;
            this.maxLengthLb.Text = "Enter the max length of room (in feet):";
            // 
            // maxLengthEnteredTx
            // 
            this.maxLengthEnteredTx.Location = new System.Drawing.Point(287, 100);
            this.maxLengthEnteredTx.Name = "maxLengthEnteredTx";
            this.maxLengthEnteredTx.Size = new System.Drawing.Size(100, 26);
            this.maxLengthEnteredTx.TabIndex = 4;
            // 
            // carpetPriceLb
            // 
            this.carpetPriceLb.AutoSize = true;
            this.carpetPriceLb.Location = new System.Drawing.Point(12, 132);
            this.carpetPriceLb.Name = "carpetPriceLb";
            this.carpetPriceLb.Size = new System.Drawing.Size(262, 20);
            this.carpetPriceLb.TabIndex = 5;
            this.carpetPriceLb.Text = "Enter the carpet price (per sq. yard):";
            // 
            // carpetPriceEnteredTx
            // 
            this.carpetPriceEnteredTx.Location = new System.Drawing.Point(287, 132);
            this.carpetPriceEnteredTx.Name = "carpetPriceEnteredTx";
            this.carpetPriceEnteredTx.Size = new System.Drawing.Size(100, 26);
            this.carpetPriceEnteredTx.TabIndex = 6;
            // 
            // layersPaddingLb
            // 
            this.layersPaddingLb.AutoSize = true;
            this.layersPaddingLb.Location = new System.Drawing.Point(12, 166);
            this.layersPaddingLb.Name = "layersPaddingLb";
            this.layersPaddingLb.Size = new System.Drawing.Size(278, 20);
            this.layersPaddingLb.TabIndex = 7;
            this.layersPaddingLb.Text = "Enter layers of padding to use (1 or 2):";
            // 
            // layersPaddingEnteredTx
            // 
            this.layersPaddingEnteredTx.Location = new System.Drawing.Point(287, 166);
            this.layersPaddingEnteredTx.Name = "layersPaddingEnteredTx";
            this.layersPaddingEnteredTx.Size = new System.Drawing.Size(100, 26);
            this.layersPaddingEnteredTx.TabIndex = 8;
            // 
            // firstRoomQLb
            // 
            this.firstRoomQLb.AutoSize = true;
            this.firstRoomQLb.Location = new System.Drawing.Point(12, 200);
            this.firstRoomQLb.Name = "firstRoomQLb";
            this.firstRoomQLb.Size = new System.Drawing.Size(275, 20);
            this.firstRoomQLb.TabIndex = 9;
            this.firstRoomQLb.Text = "Is this the first room? (1=YES, 0=NO):";
            // 
            // firstRoomQTx
            // 
            this.firstRoomQTx.Location = new System.Drawing.Point(287, 200);
            this.firstRoomQTx.Name = "firstRoomQTx";
            this.firstRoomQTx.Size = new System.Drawing.Size(100, 26);
            this.firstRoomQTx.TabIndex = 10;
            // 
            // sqYardsNeededLb
            // 
            this.sqYardsNeededLb.AutoSize = true;
            this.sqYardsNeededLb.Location = new System.Drawing.Point(12, 250);
            this.sqYardsNeededLb.Name = "sqYardsNeededLb";
            this.sqYardsNeededLb.Size = new System.Drawing.Size(143, 20);
            this.sqYardsNeededLb.TabIndex = 11;
            this.sqYardsNeededLb.Text = "Sq. Yards Needed:";
            // 
            // sqYardsNeededOutput
            // 
            this.sqYardsNeededOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqYardsNeededOutput.Location = new System.Drawing.Point(161, 250);
            this.sqYardsNeededOutput.Name = "sqYardsNeededOutput";
            this.sqYardsNeededOutput.Size = new System.Drawing.Size(100, 23);
            this.sqYardsNeededOutput.TabIndex = 12;
            // 
            // carpetCostLb
            // 
            this.carpetCostLb.AutoSize = true;
            this.carpetCostLb.Location = new System.Drawing.Point(12, 284);
            this.carpetCostLb.Name = "carpetCostLb";
            this.carpetCostLb.Size = new System.Drawing.Size(98, 20);
            this.carpetCostLb.TabIndex = 13;
            this.carpetCostLb.Text = "Carpet Cost:";
            // 
            // carpetCostOutput
            // 
            this.carpetCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.carpetCostOutput.Location = new System.Drawing.Point(161, 284);
            this.carpetCostOutput.Name = "carpetCostOutput";
            this.carpetCostOutput.Size = new System.Drawing.Size(100, 23);
            this.carpetCostOutput.TabIndex = 14;
            // 
            // paddingCostLb
            // 
            this.paddingCostLb.AutoSize = true;
            this.paddingCostLb.Location = new System.Drawing.Point(12, 323);
            this.paddingCostLb.Name = "paddingCostLb";
            this.paddingCostLb.Size = new System.Drawing.Size(108, 20);
            this.paddingCostLb.TabIndex = 15;
            this.paddingCostLb.Text = "Padding Cost:";
            // 
            // paddingCostOutput
            // 
            this.paddingCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paddingCostOutput.Location = new System.Drawing.Point(161, 323);
            this.paddingCostOutput.Name = "paddingCostOutput";
            this.paddingCostOutput.Size = new System.Drawing.Size(100, 23);
            this.paddingCostOutput.TabIndex = 16;
            // 
            // laborCostLb
            // 
            this.laborCostLb.AutoSize = true;
            this.laborCostLb.Location = new System.Drawing.Point(12, 364);
            this.laborCostLb.Name = "laborCostLb";
            this.laborCostLb.Size = new System.Drawing.Size(91, 20);
            this.laborCostLb.TabIndex = 17;
            this.laborCostLb.Text = "Labor Cost:";
            // 
            // laborCostOutput
            // 
            this.laborCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborCostOutput.Location = new System.Drawing.Point(161, 364);
            this.laborCostOutput.Name = "laborCostOutput";
            this.laborCostOutput.Size = new System.Drawing.Size(100, 23);
            this.laborCostOutput.TabIndex = 18;
            // 
            // totalCostLb
            // 
            this.totalCostLb.AutoSize = true;
            this.totalCostLb.Location = new System.Drawing.Point(12, 402);
            this.totalCostLb.Name = "totalCostLb";
            this.totalCostLb.Size = new System.Drawing.Size(85, 20);
            this.totalCostLb.TabIndex = 19;
            this.totalCostLb.Text = "Total Cost:";
            // 
            // totalCostOutput
            // 
            this.totalCostOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOutput.Location = new System.Drawing.Point(161, 402);
            this.totalCostOutput.Name = "totalCostOutput";
            this.totalCostOutput.Size = new System.Drawing.Size(100, 23);
            this.totalCostOutput.TabIndex = 20;
            // 
            // estimatorCalcBtn
            // 
            this.estimatorCalcBtn.Location = new System.Drawing.Point(449, 250);
            this.estimatorCalcBtn.Name = "estimatorCalcBtn";
            this.estimatorCalcBtn.Size = new System.Drawing.Size(154, 54);
            this.estimatorCalcBtn.TabIndex = 21;
            this.estimatorCalcBtn.Text = "Estimator Calculator";
            this.estimatorCalcBtn.UseVisualStyleBackColor = true;
            this.estimatorCalcBtn.Click += new System.EventHandler(this.estimatorCalcBtn_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.estimatorCalcBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.estimatorCalcBtn);
            this.Controls.Add(this.totalCostOutput);
            this.Controls.Add(this.totalCostLb);
            this.Controls.Add(this.laborCostOutput);
            this.Controls.Add(this.laborCostLb);
            this.Controls.Add(this.paddingCostOutput);
            this.Controls.Add(this.paddingCostLb);
            this.Controls.Add(this.carpetCostOutput);
            this.Controls.Add(this.carpetCostLb);
            this.Controls.Add(this.sqYardsNeededOutput);
            this.Controls.Add(this.sqYardsNeededLb);
            this.Controls.Add(this.firstRoomQTx);
            this.Controls.Add(this.firstRoomQLb);
            this.Controls.Add(this.layersPaddingEnteredTx);
            this.Controls.Add(this.layersPaddingLb);
            this.Controls.Add(this.carpetPriceEnteredTx);
            this.Controls.Add(this.carpetPriceLb);
            this.Controls.Add(this.maxLengthEnteredTx);
            this.Controls.Add(this.maxLengthLb);
            this.Controls.Add(this.maxWidthEnteredTx);
            this.Controls.Add(this.maxWidthLb);
            this.Controls.Add(this.titleProgram);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleProgram;
        private System.Windows.Forms.Label maxWidthLb;
        private System.Windows.Forms.TextBox maxWidthEnteredTx;
        private System.Windows.Forms.Label maxLengthLb;
        private System.Windows.Forms.TextBox maxLengthEnteredTx;
        private System.Windows.Forms.Label carpetPriceLb;
        private System.Windows.Forms.TextBox carpetPriceEnteredTx;
        private System.Windows.Forms.Label layersPaddingLb;
        private System.Windows.Forms.TextBox layersPaddingEnteredTx;
        private System.Windows.Forms.Label firstRoomQLb;
        private System.Windows.Forms.TextBox firstRoomQTx;
        private System.Windows.Forms.Label sqYardsNeededLb;
        private System.Windows.Forms.Label sqYardsNeededOutput;
        private System.Windows.Forms.Label carpetCostLb;
        private System.Windows.Forms.Label carpetCostOutput;
        private System.Windows.Forms.Label paddingCostLb;
        private System.Windows.Forms.Label paddingCostOutput;
        private System.Windows.Forms.Label laborCostLb;
        private System.Windows.Forms.Label laborCostOutput;
        private System.Windows.Forms.Label totalCostLb;
        private System.Windows.Forms.Label totalCostOutput;
        private System.Windows.Forms.Button estimatorCalcBtn;
    }
}

