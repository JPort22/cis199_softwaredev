﻿namespace Lab7
{
    partial class Lab7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordsTypedLb = new System.Windows.Forms.Label();
            this.wordsTypedTxBxInput = new System.Windows.Forms.TextBox();
            this.gradeEarnedLb = new System.Windows.Forms.Label();
            this.gradeEarnedLbOutput = new System.Windows.Forms.Label();
            this.titleLb = new System.Windows.Forms.Label();
            this.calcGradeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wordsTypedLb
            // 
            this.wordsTypedLb.AutoSize = true;
            this.wordsTypedLb.Location = new System.Drawing.Point(38, 127);
            this.wordsTypedLb.Name = "wordsTypedLb";
            this.wordsTypedLb.Size = new System.Drawing.Size(217, 20);
            this.wordsTypedLb.TabIndex = 0;
            this.wordsTypedLb.Text = "Enter number of words typed:";
            // 
            // wordsTypedTxBxInput
            // 
            this.wordsTypedTxBxInput.Location = new System.Drawing.Point(272, 124);
            this.wordsTypedTxBxInput.Name = "wordsTypedTxBxInput";
            this.wordsTypedTxBxInput.Size = new System.Drawing.Size(100, 26);
            this.wordsTypedTxBxInput.TabIndex = 1;
            // 
            // gradeEarnedLb
            // 
            this.gradeEarnedLb.AutoSize = true;
            this.gradeEarnedLb.Location = new System.Drawing.Point(141, 163);
            this.gradeEarnedLb.Name = "gradeEarnedLb";
            this.gradeEarnedLb.Size = new System.Drawing.Size(114, 20);
            this.gradeEarnedLb.TabIndex = 2;
            this.gradeEarnedLb.Text = "Grade Earned:";
            // 
            // gradeEarnedLbOutput
            // 
            this.gradeEarnedLbOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeEarnedLbOutput.Location = new System.Drawing.Point(272, 160);
            this.gradeEarnedLbOutput.Name = "gradeEarnedLbOutput";
            this.gradeEarnedLbOutput.Size = new System.Drawing.Size(100, 23);
            this.gradeEarnedLbOutput.TabIndex = 3;
            // 
            // titleLb
            // 
            this.titleLb.AutoSize = true;
            this.titleLb.Location = new System.Drawing.Point(321, 42);
            this.titleLb.Name = "titleLb";
            this.titleLb.Size = new System.Drawing.Size(139, 20);
            this.titleLb.TabIndex = 4;
            this.titleLb.Text = "Find Your Grade!!!";
            // 
            // calcGradeBtn
            // 
            this.calcGradeBtn.Location = new System.Drawing.Point(543, 144);
            this.calcGradeBtn.Name = "calcGradeBtn";
            this.calcGradeBtn.Size = new System.Drawing.Size(152, 60);
            this.calcGradeBtn.TabIndex = 5;
            this.calcGradeBtn.Text = "Calculate Grade!!!";
            this.calcGradeBtn.UseVisualStyleBackColor = true;
            this.calcGradeBtn.Click += new System.EventHandler(this.calcGradeBtn_Click);
            // 
            // Lab7
            // 
            this.AcceptButton = this.calcGradeBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.calcGradeBtn);
            this.Controls.Add(this.titleLb);
            this.Controls.Add(this.gradeEarnedLbOutput);
            this.Controls.Add(this.gradeEarnedLb);
            this.Controls.Add(this.wordsTypedTxBxInput);
            this.Controls.Add(this.wordsTypedLb);
            this.Name = "Lab7";
            this.Text = "Lab7Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wordsTypedLb;
        private System.Windows.Forms.TextBox wordsTypedTxBxInput;
        private System.Windows.Forms.Label gradeEarnedLb;
        private System.Windows.Forms.Label gradeEarnedLbOutput;
        private System.Windows.Forms.Label titleLb;
        private System.Windows.Forms.Button calcGradeBtn;
    }
}

