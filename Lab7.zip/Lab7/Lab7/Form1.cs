﻿//Grading ID: M4318
//CIS 199-01
//Lab 7
//Due Date: 03/24/2019
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7 : Form
    {
        public Lab7()
        {
            InitializeComponent();
        }
        //The purpose for this lab is to calculate a students grades based on their words typed per minute
        private void calcGradeBtn_Click(object sender, EventArgs e)
        {
            int wordsTyped;//variable for user input
            int[] wordsTypedRangeLowLimits = { 0, 16, 31, 51, 76 };//range limits in numbers for words typed
            char[] gradeEarnedRange = { 'F', 'D', 'C', 'B', 'A' };//grade scale from lowest to highest
            bool found = false;//bool variable for code conditions
            char gradeEarned = 'F';//lowest grade for code to start checking
            if(int.TryParse(wordsTypedTxBxInput.Text, out wordsTyped)&& wordsTyped > 0)//code conditions that read input and put it into variable
            {//code begins to look through ranges and limits
                int index = wordsTypedRangeLowLimits.Length - 1;
                while(wordsTyped >= 0 && !found)//checks input from user to assing it to a grade
                {
                    if (wordsTyped >= wordsTypedRangeLowLimits[index])
                        found = true;
                    else//goes through range for grade by decrementing
                        --index; 
                }
                if (found)//assigns range and wordsTyped
                {//Output
                    gradeEarned = gradeEarnedRange[index];
                    gradeEarnedLbOutput.Text = ($"{gradeEarned}");
                }
               
            }
            else//error message box show
            {
                MessageBox.Show("Enter valid number.");
            }

        }
    }
}
