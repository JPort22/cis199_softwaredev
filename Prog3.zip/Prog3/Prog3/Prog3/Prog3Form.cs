﻿// Grading ID: M4318
//Program 3
// CIS 199-01
// Due: 3/30/2019
// Based off code from: Andrew L. Wright 

// This application calculates the marginal tax rate and
// tax due for filers in 2019 tax year.

// Version 3
// Listens to radio buttons to apply income thresholds
// Calculates tax due through running total with each
// tier's portion of the tax.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog3
{
    public partial class Prog3Form : Form
    {
        // Tax Year 2019 Data
        // Taxable income thresholds for each status
        // Single Filers
        private const int SINGLE1 = 9700;   // 1st single threshold (LOWEST)
        private const int SINGLE2 = 39475;  // 2nd single threshold
        private const int SINGLE3 = 84200;  // 3rd single threshold
        private const int SINGLE4 = 160725; // 4th single threshold
        private const int SINGLE5 = 204100; // 5th single threshold
        private const int SINGLE6 = 510300; // 6th single threshold (HIGHEST)
        int[] singles = { 1, SINGLE1 + 1, SINGLE2 + 1, SINGLE3 + 1, SINGLE4 + 1, SINGLE5 + 1, SINGLE6 + 1 };

        //Married Filing Separately
        private const int SEPARATELY1 = 9700;   // 1st married-separately threshold (LOWEST)
        private const int SEPARATELY2 = 39475;  // 2nd married-separately threshold
        private const int SEPARATELY3 = 84200;  // 3rd married-separately threshold
        private const int SEPARATELY4 = 160725; // 4th married-separately threshold
        private const int SEPARATELY5 = 204100; // 5th married-separately threshold
        private const int SEPARATELY6 = 306175; // 6th married-separately threshold (HIGHEST)
        int[] separates = { 1, SEPARATELY1 + 1, SEPARATELY2 + 1, SEPARATELY3 + 1, SEPARATELY4 + 1, SEPARATELY5 + 1, SEPARATELY6 + 1 };
        // Married Filing Jointly
        private const int JOINTLY1 = 19400;  // 1st married-jointly threshold (LOWEST)
        private const int JOINTLY2 = 78950;  // 2nd married-jointly threshold
        private const int JOINTLY3 = 168400; // 3rd married-jointly threshold
        private const int JOINTLY4 = 321450; // 4th married-jointly threshold
        private const int JOINTLY5 = 408200; // 5th married-jointly threshold
        private const int JOINTLY6 = 612350; // 6th married-jointly threshold (HIGHEST)
        int[] joints = { 1, JOINTLY1 + 1, JOINTLY2 + 1, JOINTLY3 + 1, JOINTLY4 + 1, JOINTLY5 + 1, JOINTLY6 + 1 };
        // Head of Household
        private const int HOH1 = 13850;  // 1st head of household threshold (LOWEST)
        private const int HOH2 = 52850;  // 2nd head of household threshold
        private const int HOH3 = 84200;  // 3rd head of household threshold
        private const int HOH4 = 160700; // 4th head of household threshold
        private const int HOH5 = 204100; // 5th head of household threshold
        private const int HOH6 = 510300; // 6th head of household threshold (HIGHEST)
        int[] hohs = { 1, HOH1 + 1, HOH2 + 1, HOH3 + 1, HOH4 + 1, HOH5 + 1, HOH6 + 1 };
        // Income threshold values that apply to this filer

        int[] thresholds = new int[7];//array for thresholds
        public Prog3Form()
        {
            InitializeComponent();
        }

        // User has clicked the Calculate Tax button
        // Will calculate and display their marginal tax rate and tax due
        private void calcTaxBtn_Click(object sender, EventArgs e)
        {
            // Tax Year 2019 Data
            // The marginal tax rates
            const decimal RATE1 = .10m; // 1st tax rate (LOWEST)
            const decimal RATE2 = .12m; // 2nd tax rate
            const decimal RATE3 = .22m; // 3rd tax rate
            const decimal RATE4 = .24m; // 4th tax rate
            const decimal RATE5 = .32m; // 5th tax rate
            const decimal RATE6 = .35m; // 6th tax rate
            const decimal RATE7 = .37m; // 7th tax rate (HIGHEST)
            decimal[] rates = { RATE1, RATE2, RATE3, RATE4, RATE5, RATE6, RATE7 };//array for the rates used in calculation
            
            
            int income; // Filer's taxable income (input)

            decimal marginalRate; // Filer's calculated marginal tax rate
            decimal tax= 0;          // Filer's calculated income tax due
            decimal currentTax;   // Filer's tax for current tier

            if (int.TryParse(incomeTxt.Text, out income) && income >= 0)
            {
                // Calculate income tax due and find their marginal rate
                // Uses running total approach
                // Math.Min returns the smaller of two values
                marginalRate = RATE1;// Assume lowest rate
                bool found = false;//for finding true conditions and range match
                int index = thresholds.Length - 1;//index position being declared

                
                //uses thresholds to search by going through each one and it's index
                while (index >= 0 && !found)
                {
                    if (income >= thresholds[index])
                        found = true;
                    else
                        --index;
                }
                //this assigns the rates by going through the array
                marginalRate = rates[index];
                //finds what income belongs in what threshold and calculates tax due by going through these positions in the thresholds and multiplying it by the appropriate rate and such
                if(income > thresholds[6])
                {
                    for (int x=0; x <= index - 1; ++x)
                    {
                        currentTax = Math.Min((income -(thresholds[x] - 1)), (thresholds[x + 1] - thresholds[x])) * rates[x];
                        tax += currentTax;
                    }
                    currentTax = (income - (thresholds[6] - 1)) * rates[6];
                    tax = currentTax + tax;
                }
                else//conditions for lower range of the threshold that also calculates the tax due for income given
                {
                    for(int x = 0; x <= index; ++x)
                    {
                        currentTax = Math.Min((income - (thresholds[x] - 1)), (thresholds[x + 1] - thresholds[x])) * rates[x];
                        tax = currentTax + tax;
                    }
                }
                


                // Output results
                marginalRateOutLbl.Text = $"{marginalRate:P0}";
                taxOutLbl.Text = $"{tax:C}";
            }
            else // Invalid input
                MessageBox.Show("Enter valid income!");
        }

        // Form is loading
        // Sets default filing status as Single
        private void Prog2Form_Load(object sender, EventArgs e)
        {
            singleRdoBtn.Checked = true; // Choose single by default
                                         // Will raise CheckedChanged event
        }

        // User has checked/unchecked Single radio button
        // Updates income thresholds
        private void singleRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (singleRdoBtn.Checked) // Single?
            {
              for(int index = 0; index < thresholds.Length; ++index)
              {
                    thresholds[index] = singles[index];
              }
                
                
            }
        }

        // User has checked/unchecked Married Filing Separately radio button
        // Updates income thresholds
        private void separatelyRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (separatelyRdoBtn.Checked) // Married Filing Separately?
            {
                for(int index= 0; index < thresholds.Length; ++index)
                {
                    thresholds[index] = separates[index];
                }
            }
        }

        // User has checked/unchecked Married Filing Jointly radio button
        // Updates income thresholds
        private void jointlyRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (jointlyRdoBtn.Checked) // Married Filing Jointly?
            {
                for(int index = 0; index < thresholds.Length; ++index)
                {
                    thresholds[index] = joints[index];
                }
            }
        }

        // User has checked/unchecked Head of Household radio button
        // Updates income thresholds
        private void headOfHouseRdoBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (headOfHouseRdoBtn.Checked) // Head of Household?
            {
               for(int index = 0; index < thresholds.Length; ++index)
                {
                    thresholds[index] = hohs[index];
                }
            }
        }
    }
}
